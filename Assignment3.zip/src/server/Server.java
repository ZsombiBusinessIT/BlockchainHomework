package server;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.util.Base64;

public class Server {
    public static void main(String[] args) {
        try { //try it first to prevent Error like: Actual port is not available:)
            //HUN: Szerver socket létrehozása és hallgatása a megadott porton
            // Create a server socket the appropriate port
            ServerSocket serverSocket = new ServerSocket(12345);
            System.out.println("Smart Contract Server is running...");

            while (true) { //always true -> till Server is alive
                Socket socket = serverSocket.accept();
                System.out.println("Connection established with client: " + socket.getInetAddress());

                //Smart contract inicializálása és Node A publikus kulcsának elküldése
                //Smart contract initialization and sending of Node A's public key
                PublicKey publicKey = initContract(socket);
                sendPublicKey(socket, publicKey);

                // Adatok fogadása Node B től és visszafejtés
                // Receive data from Node B and decrypt it
                String encryptedData = receiveEncryptedData(socket);
                System.out.println("Decrypted data received from Node B: " + encryptedData);

                socket.close();
            }
        } catch (IOException | NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
    }

    private static PublicKey initContract(Socket socket) throws NoSuchAlgorithmException {
        // RSA kulcspár generálása Node A számára
        // Generate RSA keypair for Node A
        KeyPairGenerator keyPairGen = KeyPairGenerator.getInstance("RSA");
        keyPairGen.initialize(2048);
        KeyPair keyPair = keyPairGen.generateKeyPair();

        // Node A publikus kulcsának elküldése
        // Send Node A's public key
        return keyPair.getPublic();
    }

    private static void sendPublicKey(Socket socket, PublicKey publicKey) throws IOException {
        // Publikus kulcs String-é alakítása és elküldése a kliensnek
        // Convert public key to String and send it to the client
        DataOutputStream dos = new DataOutputStream(socket.getOutputStream());
        dos.writeUTF(Base64.getEncoder().encodeToString(publicKey.getEncoded()));
    }

    private static String receiveEncryptedData(Socket socket) throws IOException {
        // Titkosított adatok fogadása Node B-től
        // Convert public key to String and send it to the client
        DataInputStream dis = new DataInputStream(socket.getInputStream());
        return dis.readUTF();
    }
}
