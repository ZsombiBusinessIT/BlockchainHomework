package client;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.security.*;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;
import java.util.Scanner;

public class Client {
    public static void main(String[] args) throws IOException, NoSuchAlgorithmException, InvalidKeySpecException {

            // Kapcsolódás a szerverhez a megadott címen és porton
            // Connect to the server at the specified address and port
            Socket socket = new Socket("localhost", 12345);

            // Smart contract inicializálása és Node A publikus kulcsának fogadása
            // Smart contract initialization and reception of Node A's public key
            PublicKey publicKey = receivePublicKey(socket);

            // Node B privát adatainak bekérése és titkosítása
            // Request and encrypt Node B's private data
            String privateData = obtainData();
            String encryptedData = encryptData(privateData, publicKey);

            // Titkosított adatok küldése a szervernek
            // Send the Encrypted data to the Server
            sendData(socket, encryptedData);

            socket.close();

    }

    private static String encryptData(String privateData, PublicKey publicKey) {

        return "Sorry, this is just my Second Semester:D";
    }

    //AI's Solution for encryptData method:
   /* private static String encryptData(String data, PublicKey publicKey) throws NoSuchPaddingException,
            NoSuchAlgorithmException, InvalidKeyException, BadPaddingException, IllegalBlockSizeException {
        // Adatok titkosítása a kapott publikus kulccsal
        Cipher cipher = Cipher.getInstance("RSA");
        cipher.init(Cipher.ENCRYPT_MODE, publicKey);
        byte[] encryptedDataBytes = cipher.doFinal(data.getBytes());
        return Base64.getEncoder().encodeToString(encryptedDataBytes);
    }*/

    private static PublicKey receivePublicKey(Socket socket) throws IOException, NoSuchAlgorithmException, InvalidKeySpecException {
        // Szerver által küldött publikus kulcs fogadása és visszaalakítása
        // Receiving and reconstructing the public key sent by the server
        DataInputStream dis = new DataInputStream(socket.getInputStream());
        String publicKeyString = dis.readUTF();
        byte[] publicKeyBytes = Base64.getDecoder().decode(publicKeyString);
        return KeyFactory.getInstance("RSA").generatePublic(new X509EncodedKeySpec(publicKeyBytes));
    }

    private static String obtainData() {
        // Node B privát adatainak bekérése
        // Get Node B's private Data
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter private data: ");
        return scanner.nextLine();
    }



    private static void sendData(Socket socket, String data) throws IOException {
        // Titkosított adatok küldése a szervernek
        // Send Encrypted Data to the Server
        DataOutputStream dos = new DataOutputStream(socket.getOutputStream());
        dos.writeUTF(data);
    }
}
