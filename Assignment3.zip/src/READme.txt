# Secure Communication System Proof-of-Concept (SCS_PoC)

## Important Notice
This project is a Proof-of-Concept implementation showcasing the basic mechanisms of secure communication.

There are 2 Classes: Server.java and Client.java
I have added comments in the Classes where I thought necessary.

This project demonstrates a simple Proof-of-Concept implementation of a secure communication system using Java. :-) 
The system consists of three main components: 
A Smart Contract Server and two clients (Node A and Node B) engaging in encrypted communication mediated 
by the Smart Contract Server.

## Installation and Execution

1. **Clone the Project**: Clone the project to your local machine from the Github repository:

    ```bash
    git clone https://github.com/username/SCS_PoC.git
    ```

2. **Import Project into IDE**: Open the project in a Java Integrated Development Environment (IDE) such as IntelliJ IDEA or Eclipse.

3. **Run the Project**: Start the Smart Contract Server, then separately start the Node A and Node B clients.

4. **Follow the comments in the code for execution and communication**.

Thank you!
