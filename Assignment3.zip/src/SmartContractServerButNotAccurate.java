/*import java.io.*;
import java.net.*;
//THIS KIND OF SOLUTION IS 3 IN ONE, but it does not accurate
public class SmartContractServer {
    public static void main(String[] args) {
        try { //We use here Try-Catch to prevent Errors
            // Create a server socket on the specified port
            ServerSocket serverSocket = new ServerSocket(12345);
            System.out.println("Smart Contract Server is running...");

            while (true) {
                Socket clientSocket = serverSocket.accept();
                System.out.println("Connection established with client: " + clientSocket.getInetAddress());

                // Request private data from Node A
                String privateData = receiveData(clientSocket);
                System.out.println("Private data received from Node A: " + privateData);

                // Smart contract initialization and sending Node A's public key to Node B
                String publicKey = "PKa(Sign, Timestamp)";
                sendPublicKey(clientSocket, publicKey);

                // Node B-től titkosított adatok fogadása és visszafejtése
                String encryptedData = receiveEncryptedData(clientSocket);
                String decryptedData = decryptData(encryptedData);
                System.out.println("Decrypted data received from Node B: " + decryptedData);

                clientSocket.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static String receiveData(Socket socket) throws IOException {
        // Node A-tól privát adatok fogadása
        // Receiving private data from Node A
        DataInputStream dis = new DataInputStream(socket.getInputStream());
        return dis.readUTF();
    }

    private static void sendPublicKey(Socket socket, String publicKey) throws IOException {
        // Node A publikus kulcsának elküldése Node B-nek
        // Sending Node A's public key to Node B
        DataOutputStream dos = new DataOutputStream(socket.getOutputStream());
        dos.writeUTF(publicKey);
    }

    private static String receiveEncryptedData(Socket socket) throws IOException {
        // Titkosított adatok fogadása Node B-től
        DataInputStream dis = new DataInputStream(socket.getInputStream());
        return dis.readUTF();
    }

    private static String decryptData(String encryptedData) {
        // Titkosított adatok visszafejtése Node A privát kulcsával
        // Ebben a példában a visszafetés csak szimulált, mivel nincs blokklánc integráció
        return "Decrypted data";
    }
}*/
